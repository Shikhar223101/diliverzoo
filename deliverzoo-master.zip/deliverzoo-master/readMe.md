# Responsive Food Ordering Website with HTML, CSS and JavaScript


The Figma file of the Responsive Food Ordering Website can be found on 

[https://www.figma.com/file/CLvaLMD9wL47un4iJ3JtlN/Food-Ordering-Landing-Page-Design?node-id=0%3A1]
